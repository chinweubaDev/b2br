<!DOCTYPE html>
<html>
<head>
    <title>Royeli Tours & Travel</title>
</head>
<body>
    <h1>Welcome to Royeli Tours & Travel</h1>
</body>
</html>